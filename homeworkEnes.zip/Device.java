public interface Device {
    
    public String getCategory();

    public String getName();

    public double getPrice();

    public void setPrice(double price);

    public int getQuantity();

    public void setQuantity(int quantity);

}
